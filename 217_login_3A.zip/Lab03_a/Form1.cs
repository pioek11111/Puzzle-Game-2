﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab03_a
{
    public partial class Form1 : Form
    {
        int[,] arr;
        int[,] label;
        public Form1()
        {
            InitializeComponent();
            arr = new int[5, 5];
            label = new int[5, 5];
            foreach (Button button in tableLayoutPanel1.Controls)
            {
                button.Enabled = false;
                button.BackColor = this.BackColor;                
                button.MouseDown += mouseClicked;
                button.MouseEnter += mouseEnter;
                button.MouseLeave += mouseLeave;
                //MouseEnter
            }
        }

        private void mouseLeave(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if(button.BackColor != Color.Black) button.BackColor = this.BackColor;
        }

        private void mouseEnter(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if(button.BackColor == this.BackColor) button.BackColor = Color.Yellow;
        }

     
        private void mouseClicked(object sender, MouseEventArgs me)
        {
            
            Button button = sender as Button;
            if (me.Button == MouseButtons.Left)
            {
                var idx = GetIndexes(button);
                //if(arr[0, idx.Key] > )
                button.BackColor = Color.Black;
                
                arr[0, idx.Key]++;
                arr[idx.Value, 0]++;
            }
            if (me.Button == MouseButtons.Right && button.BackColor != Color.Yellow)
            {
                button.BackColor = this.BackColor;
                var idx = GetIndexes(button);
                arr[0, idx.Key]--;
                arr[idx.Value, 0]--;
                //button.BackColor = Color.Red;
            }
        }
        private KeyValuePair<Label, Label> getLable(Button button)
        {
            switch (button.Name)
            {
                case "button1":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button2":
                    {
                        return new KeyValuePair<Label, Label>(label2, label5);
                    }
                case "button3":
                    {
                        return new KeyValuePair<Label, Label>(label3, label5);
                    }
                case "button4":
                    {
                        return new KeyValuePair<Label, Label>(label4, label5);
                    }
                case "button5":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button6":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button7":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button8":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button9":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button10":
                    {
                        return  new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button11":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button12":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button13":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button14":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button15":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
                case "button16":
                    {
                        return new KeyValuePair<Label, Label>(label1, label5);
                    }
            }
            return new KeyValuePair<Label, Label>(label1, label5);
        }
        private KeyValuePair<int, int> GetIndexes(Button button)
        {
            switch (button.Name)
            {
                case "button1":
                    {
                        return new KeyValuePair<int, int>(0, 0);
                    }
                case "button2":
                    {
                        return new KeyValuePair<int, int>(0, 1);
                    }
                case "button3":
                    {
                        return new KeyValuePair<int, int>(0, 2);
                    }
                case "button4":
                    {
                        return new KeyValuePair<int, int>(0, 3);
                    }
                case "button5":
                    {
                        return new KeyValuePair<int, int>(1, 0);
                    }
                case "button6":
                    {
                        return new KeyValuePair<int, int>(1, 1);
                    }
                case "button7":
                    {
                        return new KeyValuePair<int, int>(1, 2);
                    }
                case "button8":
                    {
                        return new KeyValuePair<int, int>(1, 3);
                    }
                case "button9":
                    {
                        return new KeyValuePair<int, int>(2, 0);
                    }
                case "button10":
                    {
                        return new KeyValuePair<int, int>(2, 1);
                    }
                case "button11":
                    {
                        return new KeyValuePair<int, int>(2, 2);
                    }
                case "button12":
                    {
                        return new KeyValuePair<int, int>(2, 3);
                    }
                case "button13":
                    {
                        return new KeyValuePair<int, int>(3, 0);
                    }
                case "button14":
                    {
                        return new KeyValuePair<int, int>(3, 1);
                    }
                case "button15":
                    {
                        return new KeyValuePair<int, int>(3, 2);
                    }
                case "button16":
                    {
                        return new KeyValuePair<int, int>(3, 3);
                    }
            }
            return new KeyValuePair<int, int>(-1, -1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs me)
        {
            //Button button = sender as Button;
            //if (me.Button == MouseButtons.Left)
            //{
            //    button.BackColor = Color.Black;
            //}
            //if (me.Button == MouseButtons.Right)
            //{
            //    button.BackColor = Color.Red;
            //}
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            foreach (Control c in this.Controls)
            {
                if (c.GetType() == typeof(Label))
                {
                    c.Text = rand.Next(0, 4).ToString();
                    ///label[]
                }
            }
            foreach (Button button in tableLayoutPanel1.Controls)
            {
                button.Enabled = true;
                button.BackColor = this.BackColor;                
            }
        }
    }
}
